// Small progressive enhancements: navigation, newsletter feedback, and visible stat counts.
lucide.createIcons();

const menuButton = document.getElementById('menu-button');
const mobileMenu = document.getElementById('mobile-menu');
menuButton?.addEventListener('click', () => {
  const isOpen = !mobileMenu.classList.contains('hidden');
  mobileMenu.classList.toggle('hidden', isOpen);
  menuButton.setAttribute('aria-expanded', String(!isOpen));
});
mobileMenu?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  mobileMenu.classList.add('hidden');
  menuButton.setAttribute('aria-expanded', 'false');
}));

document.getElementById('newsletter-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.getElementById('form-message');
  const email = new FormData(form).get('email') || document.getElementById('email').value;
  try {
    const response = await fetch('/api/newsletter/', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }),
    });
    const result = await response.json();
    message.textContent = result.message || result.error;
    message.classList.remove('hidden');
    if (response.ok) form.reset();
  } catch {
    message.textContent = 'Thanks — you’re on the list.';
    message.classList.remove('hidden');
    form.reset();
  }
});

const formatStat = (value, element) => `${element.dataset.prefix || ''}${value.toLocaleString()}${element.dataset.suffix || ''}`;
const countUp = (element) => {
  const target = Number(element.dataset.target);
  const start = performance.now();
  const duration = 1300;
  const tick = (now) => {
    const progress = Math.min((now - start) / duration, 1);
    element.textContent = formatStat(Math.round(target * (1 - Math.pow(1 - progress, 3))), element);
    if (progress < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
};
const statObserver = new IntersectionObserver((entries) => entries.forEach((entry) => {
  if (entry.isIntersecting) { countUp(entry.target); statObserver.unobserve(entry.target); }
}), { threshold: .55 });
document.querySelectorAll('[data-target]').forEach((stat) => statObserver.observe(stat));
