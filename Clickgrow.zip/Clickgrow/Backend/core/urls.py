from django.urls import path
from . import views

urlpatterns = [
    path("", views.HomeView.as_view(), name="home"),
    path("accounts/register/", views.RegisterView.as_view(), name="register"),
    path("accounts/login/", views.LoginView.as_view(), name="login"),
    path("accounts/logout/", views.logout_view, name="logout"),
    path("api/auth/register/", views.api_register, name="api-register"),
    path("api/auth/login/", views.api_login, name="api-login"),
    path("api/auth/logout/", views.api_logout, name="api-logout"),
    path("api/auth/me/", views.api_me, name="api-me"),
    path("api/contact/", views.api_contact, name="api-contact"),
    path("api/newsletter/", views.api_newsletter, name="api-newsletter"),
]
