from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={"autocomplete": "email", "placeholder": "you@company.com"}))

    class Meta:
        model = User
        fields = ("first_name", "username", "email", "password1", "password2")
        widgets = {
            "first_name": forms.TextInput(attrs={"placeholder": "Your name", "autocomplete": "name"}),
            "username": forms.TextInput(attrs={"placeholder": "Choose a username", "autocomplete": "username"}),
        }

    def clean_email(self):
        email = self.cleaned_data["email"].lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email


class EmailAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label="Email or username", widget=forms.TextInput(attrs={"placeholder": "you@company.com", "autocomplete": "username"}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={"placeholder": "Enter your password", "autocomplete": "current-password"}))

    def clean(self):
        """Accept the username Django needs internally or the user's email address."""
        identity = self.cleaned_data.get("username", "").strip()
        if "@" in identity:
            account = User.objects.filter(email__iexact=identity).first()
            if account:
                self.cleaned_data["username"] = account.username
        return super().clean()
