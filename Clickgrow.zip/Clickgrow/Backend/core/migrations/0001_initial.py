from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(name="ContactRequest", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("name", models.CharField(max_length=120)), ("email", models.EmailField(max_length=254)), ("company", models.CharField(blank=True, max_length=160)), ("message", models.TextField(max_length=3000)), ("created_at", models.DateTimeField(auto_now_add=True))]),
        migrations.CreateModel(name="NewsletterSubscriber", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("email", models.EmailField(max_length=254, unique=True)), ("subscribed_at", models.DateTimeField(auto_now_add=True))]),
    ]
