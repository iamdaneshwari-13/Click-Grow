from django.contrib import admin
from .models import ContactRequest, NewsletterSubscriber

admin.site.register(ContactRequest)
admin.site.register(NewsletterSubscriber)
