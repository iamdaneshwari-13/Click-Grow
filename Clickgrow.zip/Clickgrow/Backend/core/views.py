import json

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.views import LoginView
from django.http import JsonResponse
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt

from .forms import EmailAuthenticationForm, RegisterForm
from .models import ContactRequest, NewsletterSubscriber


class HomeView(View):
    """Render the public base template with the authenticated request context."""
    def get(self, request):
        from django.shortcuts import render
        return render(request, "base.html")


class RegisterView(View):
    template_name = "registration/register.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect("home")
        return self.render(request, RegisterForm())

    def post(self, request):
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.email = form.cleaned_data["email"]
            user.save(update_fields=["email"])
            return redirect("login")
        return self.render(request, form)

    def render(self, request, form):
        from django.shortcuts import render
        return render(request, self.template_name, {"form": form})


class LoginView(LoginView):
    template_name = "registration/login.html"
    authentication_form = EmailAuthenticationForm
    redirect_authenticated_user = True

    def form_valid(self, form):
        return super().form_valid(form)


def logout_view(request):
    logout(request)
    return redirect("home")


def json_body(request):
    try:
        return json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return None


def api_error(message, status=400):
    return JsonResponse({"ok": False, "error": message}, status=status)


@csrf_exempt
def api_register(request):
    if request.method != "POST": return api_error("POST required.", 405)
    data = json_body(request)
    if data is None: return api_error("Invalid JSON body.")
    form = RegisterForm({"first_name": data.get("name", ""), "username": data.get("username", ""), "email": data.get("email", ""), "password1": data.get("password", ""), "password2": data.get("password_confirm", "")})
    if not form.is_valid(): return JsonResponse({"ok": False, "errors": form.errors}, status=422)
    user = form.save()
    user.email = form.cleaned_data["email"]
    user.save(update_fields=["email"])
    login(request, user)
    return JsonResponse({"ok": True, "message": "Account created.", "redirect": reverse_lazy("login"), "user": {"id": user.id, "username": user.username, "email": user.email}}, status=201)


@csrf_exempt
def api_login(request):
    if request.method != "POST": return api_error("POST required.", 405)
    data = json_body(request)
    if data is None: return api_error("Invalid JSON body.")
    identity = data.get("email", "").strip()
    user = authenticate(request, username=identity, password=data.get("password", ""))
    if user is None:
        matched = User.objects.filter(email__iexact=identity).first()
        if matched: user = authenticate(request, username=matched.username, password=data.get("password", ""))
    if user is None: return api_error("Invalid email/username or password.", 401)
    login(request, user)
    return JsonResponse({"ok": True, "message": "Welcome back.", "redirect": reverse_lazy("home"), "user": {"id": user.id, "username": user.username, "email": user.email}})


@csrf_exempt
def api_logout(request):
    if request.method != "POST": return api_error("POST required.", 405)
    logout(request)
    return JsonResponse({"ok": True, "redirect": reverse_lazy("home")})


def api_me(request):
    if not request.user.is_authenticated: return api_error("Authentication required.", 401)
    user = request.user
    return JsonResponse({"ok": True, "user": {"id": user.id, "username": user.username, "email": user.email, "name": user.get_full_name()}})


@csrf_exempt
def api_contact(request):
    if request.method != "POST": return api_error("POST required.", 405)
    data = json_body(request)
    if data is None: return api_error("Invalid JSON body.")
    required = ("name", "email", "message")
    if any(not str(data.get(field, "")).strip() for field in required): return api_error("Name, email, and message are required.")
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    try: validate_email(data["email"])
    except ValidationError: return api_error("A valid email is required.")
    ContactRequest.objects.create(name=data["name"].strip(), email=data["email"].strip().lower(), company=str(data.get("company", "")).strip(), message=data["message"].strip())
    return JsonResponse({"ok": True, "message": "Thanks — we will be in touch soon."}, status=201)


@csrf_exempt
def api_newsletter(request):
    if request.method != "POST": return api_error("POST required.", 405)
    data = json_body(request)
    if data is None or not data.get("email"): return api_error("A valid email is required.")
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    try: validate_email(data["email"])
    except ValidationError: return api_error("A valid email is required.")
    _, created = NewsletterSubscriber.objects.get_or_create(email=data["email"].lower().strip())
    return JsonResponse({"ok": True, "message": "You are already subscribed." if not created else "Thanks — you're on the list."}, status=201 if created else 200)
