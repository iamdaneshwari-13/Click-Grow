# ClickGrown Django backend

## Setup

1. Install Python 3.11+ and create a virtual environment: `py -m venv .venv`
2. Activate it: `.\.venv\Scripts\Activate.ps1`
3. Install packages: `pip install -r requirements.txt`
4. Create the SQLite database: `py manage.py migrate`
5. Run locally: `py manage.py runserver`

The landing page is served at `http://127.0.0.1:8000/`. Authentication pages are available at `/accounts/login/` and `/accounts/register/`.

## API endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register/` | Create a user and start a session |
| POST | `/api/auth/login/` | Sign in with email or username |
| POST | `/api/auth/logout/` | End the active session |
| GET | `/api/auth/me/` | Get the signed-in user |
| POST | `/api/contact/` | Submit a contact request |
| POST | `/api/newsletter/` | Subscribe an email address |

JSON POST requests accept `application/json`. For browser form posts, include a valid Django CSRF token. API views are intentionally CSRF-exempt to support a separately hosted frontend; in production, restrict CORS to trusted origins and prefer CSRF-protected cookie sessions or token authentication.
